function doc(str){
            return document.getElementById(str);
        }

let array1 = [[101,"AAA"],[102,"BBB"],[103,"CCC"]]
let array2 = [[103,"Singapore"],[102,"Tokyo"],[101,"Bangkok"]]
let check = []
for(let i = 0 ; i < array1.length ; i++){
    check = array1[i]; 
    for(let j = 0; j< array2.length ; j++){
        comp = array2[j];
        if(check[0] == comp[0]){
            check.push(comp[1]);
        }
    }
    doc("C"+ (i+1).toString() ).innerText = check[0];
    doc("N"+ (i+1).toString() ).innerText = check[1];
    doc("CT"+ (i+1).toString() ).innerText = check[2];
}