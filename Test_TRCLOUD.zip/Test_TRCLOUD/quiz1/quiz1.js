
function create_star (){
    let num = document.getElementById("Numb").value;
    let prt_star = "<br>";
    let text = document.getElementById("star");
    for (let i = 0; i<num; i++){
        let count = num -i 
        if(num % 2 === 1){
            prt_star += "*".repeat(count);
        }else{
            prt_star += "*".repeat(i+1)
        }
        prt_star += "<br>"
    }
    text.innerHTML = prt_star;
}