function loadDoc() {
    var url = "https://www.trcloud.co/test/api.php";
    var res = [];
    var cout = [];
    var dataval = [];
    const barColors = ['rgba(255, 99, 132, 0.2)', 
					'rgba(54, 162, 235, 0.2)',
					'rgba(255, 206, 86, 0.2)', 
					'rgba(75, 192, 192, 0.2)',
					'rgba(153, 102, 255, 0.2)',
					'rgba(255, 159, 64, 0.2)', 
					'rgba(255, 99, 132, 0.2)', 
					'rgba(54, 162, 235, 0.2)',
					'rgba(255, 206, 86, 0.2)',
					'rgba(75, 192, 192, 0.2)', 
					'rgba(153, 102, 255, 0.2)',
					'rgba(255, 159, 64, 0.2)']
    const borderColors = ['rgba(255, 99, 132, 1)', 
					'rgba(54, 162, 235, 1)',
					'rgba(255, 206, 86, 1)', 
					'rgba(75, 192, 192, 1)',
					'rgba(153, 102, 255, 1)',
					'rgba(255, 159, 64, 1)', 
					'rgba(255, 99, 132, 1)', 
					'rgba(54, 162, 235, 1)',
					'rgba(255, 206, 86, 1)',
					'rgba(75, 192, 192, 1)', 
					'rgba(153, 102, 255, 1)',
					'rgba(255, 159, 64, 1)']
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            res = JSON.parse(this.responseText);
        }
        
        res.forEach(function(item){
            cout.push(item.City);
            dataval.push(item.Population);
        });
        console.log(cout + "\n" + dataval);
        
        var chr = document.getElementById("myChart").getContext('2d'); 
        const myChart = new Chart("myChart", {
            type: "bar",
            data: {
                labels: cout,
                datasets:[{
                    label: "Range by Contry",
                    data:dataval,
                    backgroundColor: barColors,
                    borderColor: borderColors,
                    borderWidth: 1
                }]
            },
            options: {
                scales:{
                    yAxes:[{
                        ticks:{
                            beginAtZero: true
                        }
                    }]
                }
            }
        });

        
        var chr = document.getElementById("myChart1").getContext('2d'); 
        const myChart1 = new Chart("myChart1", {
            type: "pie",
            data: {
                labels: cout,
                datasets:[{
                    label: "Range by Contry",
                    data:dataval,
                    backgroundColor: barColors,
                    borderColor: borderColors,
                    borderWidth: 1
                }]
            },
            options: {
                scales:{
                    yAxes:[{
                        ticks:{
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    };
    xhttp.open("GET", url, true);
    xhttp.send();
}

loadDoc()
