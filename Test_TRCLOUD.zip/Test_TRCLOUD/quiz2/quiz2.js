
function doc(str){
    return document.getElementById(str);
}

function cal(){
    let i;
    let check_inp = "";
    let cal_value = "";
    for(i = 1; i<=5 ; i++){
        check_inp = "inp" + i;
        if(doc(check_inp).value > 0 ){
            let diviner = doc(check_inp).value / parseInt(doc("tm_val"+i).innerHTML);
            for(let j = 1; j<= 5 ; j++){
                if(j === i){
                    continue
                }
                cal_value = "tm_val" + j;
                var res = +(diviner * parseInt(doc(cal_value).innerHTML)).toPrecision(14);
                doc("inp" + j).value = res;
            }
            break;
        };
    }
    console.log(i);
}
        